#pragma once
#include "shapegl.hpp"
namespace shapegame {


    class ShaderHandler{
    };
}
